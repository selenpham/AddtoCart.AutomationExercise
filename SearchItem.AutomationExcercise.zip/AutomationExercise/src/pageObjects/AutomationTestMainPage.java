package pageObjects;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import base.BasePage;

public class AutomationTestMainPage extends BasePage{

	public WebDriver driver;
	
	By homeIcon= By.cssSelector(".nav.navbar-nav > li:nth-of-type(1) > a");
	By productIcon = By.cssSelector(".nav.navbar-nav > li:nth-of-type(2) > a");
	By cartICon= By.cssSelector(".nav.navbar-nav > li:nth-of-type(3) > a");
	By signupICon = By.cssSelector(".nav.navbar-nav > li:nth-of-type(4) > a");

	By testcaseIcon = By.cssSelector(".nav.navbar-nav > li:nth-of-type(5) > a");
	By apiIcon = By.cssSelector(".nav.navbar-nav > li:nth-of-type(6) > a");
	By videoICon = By.cssSelector(".nav.navbar-nav > li:nth-of-type(7) > a");
	By contactICon = By.cssSelector(".nav.navbar-nav > li:nth-of-type(7) > a");

	
//	By cookie = By.cssSelector(".close-cookie-warning > span");
		
	public AutomationTestMainPage() throws IOException {
		super();
		// TODO Auto-generated constructor stub
	}

	public WebElement clickHomeIcon() throws IOException {
		this.driver = getDriver();
		return driver.findElement(homeIcon);
	}
	
	public WebElement clickProductIcon() throws IOException {
		this.driver = getDriver();
		return driver.findElement(productIcon);
	}
	
	public WebElement clickCartICon() throws IOException {
		this.driver = getDriver();
		return driver.findElement(cartICon);
	}
	
	public WebElement clickSignupICon() throws IOException {
		this.driver = getDriver();
		return driver.findElement(signupICon);
	}
	
	public WebElement clickTestcaseIcon() throws IOException {
		this.driver = getDriver();
		return driver.findElement(testcaseIcon);
	}
	
	public WebElement clickApiIcon() throws IOException {
		this.driver = getDriver();
		return driver.findElement(apiIcon);
	}
	
	public WebElement clickVideoICon() throws IOException {
		this.driver = getDriver();
		return driver.findElement(videoICon);
	}
	
	public WebElement clickcontactICon() throws IOException {
		this.driver = getDriver();
		return driver.findElement(contactICon);
	}
	
//	public WebElement getCookie() throws IOException {
//		this.driver = getDriver();
//		return driver.findElement(cookie);
//	}
}
