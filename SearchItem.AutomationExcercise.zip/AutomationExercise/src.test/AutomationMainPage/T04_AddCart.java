package AutomationMainPage;

import java.io.IOException;

import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import base.Hooks;
import pageObjects.ProductPage;

public class T04_AddCart extends Hooks{

	public T04_AddCart() throws IOException {
		super();
	}
	
	@Test
    public void tc01_searchItem() throws IOException, InterruptedException {
        
        Actions act = new Actions(getDriver());
		
        ProductPage prodPage = new ProductPage();
        //Tìm kiếm từ khóa
        prodPage.fillSearchInput().sendKeys("Stylish Dress");
        prodPage.clickSearchBtn().click();
        System.out.println("Searrch 'Stylish Dress' successful");
        //In từ khóa tìm được
        Thread.sleep(2000);
        prodPage.clickAddCartBtn().click();
        Thread.sleep(2000);
        prodPage.clickContShopping().click();
        
        prodPage.fillSearchInput().clear();
        Thread.sleep(2000);

        prodPage.fillSearchInput().sendKeys("Regular Fit Straight Jeans");
        prodPage.clickSearchBtn().click();
        System.out.println("Search 'Regular Fit Straight Jeans' successful");

        Thread.sleep(1000);

		act.sendKeys(Keys.PAGE_DOWN).perform();
        Thread.sleep(1000);

        Thread.sleep(2000);
        prodPage.clickAddCartBtn().click();
        System.out.println("Add item to cart successful");

        Thread.sleep(2000);
     
        prodPage.clickViewCart().click();
        Thread.sleep(2000);
//Scroll trang xuống
        
		act.sendKeys(Keys.PAGE_DOWN).perform();
        Thread.sleep(1000);
		act.sendKeys(Keys.PAGE_UP).perform();
        Thread.sleep(2000);

        prodPage.clickDelIcon().click();
        System.out.println("Delete item from cart successful");

        Thread.sleep(2000);
        prodPage.clickProCheckout().click();

    }
	    
}
