package AutomationMainPage;

import static org.testng.Assert.assertEquals;

import java.io.IOException;
import java.sql.Driver;
import java.util.List;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import base.Hooks;
import pageObjects.ProductPage;

@Listeners(resources.Listeners.class)
public class T03_ProductSearch extends Hooks{

	public T03_ProductSearch() throws IOException {
		super();
	}
	
	@Test
    public void tc01_searchItem() throws IOException, InterruptedException {

        ProductPage prodPage = new ProductPage();
  
//Tìm kiếm từ khóa
        prodPage.fillSearchInput().sendKeys("Stylish Dress");
        prodPage.clickSearchBtn().click();
        Thread.sleep(3000);
        
//Scroll trang xuống
        
        Actions act = new Actions(getDriver());
		act.sendKeys(Keys.PAGE_DOWN).perform();
//In từ khóa tìm được

        int numberOfResults = prodPage.getSearchResultsCount();
        if (numberOfResults == 1) {
            System.out.println("Only 1 result found for search query 'Stylish Dress'");
        } else {
            System.out.println("More than 1 result found for search query 'Stylish Dress'");
        }
        System.out.println("Number of search results: " + numberOfResults);
        Thread.sleep(2000);
//Kiểm tra tên kết quả
       
        List<WebElement> resultName = prodPage.getResultName();
        assertEquals(resultName.get(0).getText(), "Stylish Dress", "Result name does not match expected value");

//Kiểm tra giá kết quả

        List<WebElement> resultPrice = prodPage.getResultPrice();
        assertEquals(resultPrice.get(0).getText(), "Rs. 1500", "Result price does not match expected value");
        System.out.println("Price of product is: "+resultPrice.get(0).getText());
    }
    
}
